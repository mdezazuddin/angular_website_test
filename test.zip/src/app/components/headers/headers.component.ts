import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-headers',
  templateUrl: './headers.component.html',
  styleUrls: ['./headers.component.scss']
})
export class HeadersComponent implements OnInit {
  showFiller = false;

  scrolsHeader_variables = false;
  scrolsTop_variables = true;
  @HostListener("document:scroll")

  onScroll(){
    if(document.body.scrollTop > 500 || document.documentElement.scrollTop > 500){
      this.scrolsHeader_variables=true;
    }else{
      this.scrolsHeader_variables=false;
    }

    if(document.body.scrollTop > 1100 || document.documentElement.scrollTop > 1100){
      this.scrolsTop_variables=false;
    }else{
      this.scrolsTop_variables=true;
    }
  }

  /*scrollToTop() {
    (function smoothscroll() {
        var currentScroll = document.documentElement.scrollTop || document.body.scrollTop;
        if (currentScroll > 0) {
            window.requestAnimationFrame(smoothscroll);
            window.scrollTo(0, currentScroll - (currentScroll / 12));
        }
    })();
  }*/
  
  constructor() { }

  ngOnInit(): void {
  }

}
