import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';

@Component({
  selector: 'app-client-logo',
  template: `
    <!-- section10 -->
    <section class="section10 pb-5 bg-header">
      <owl-carousel-o [options]="customOptions">
        <ng-template carouselSlide>
          <div class="container pt-5">
            <div class="row align-items-center pt-5 pb-4">
              <div class="col-12 col-lg-6 mt-md-4 ml-md-auto text-left text-white left-reveal">
                  <h4>Business grow strategy is our mission</h4>
                  <h1 class="mt-4 h2">Take Your Business To The Next Level With Our Agency</h1>
                  <p class="mt-3 text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae soluta, dignissimos aut, assumenda dolore totam natus
                  qui cum vel omnis voluptates.</p>
                  <p class="mt-5" >
                      <a class="btn btn-primary rounded-pill px-sm-5 px-3 py-3 mt-4" href="#"> Contac Us</a>
                      <a class="btn btn-primary rounded-pill px-sm-5 px-3 py-3 ms-2 mt-4" href="#">Learn More</a> 
                  </p>
              </div>
              <div class="col-12 col-lg-6 mt-4 text-md-right right-reveal">
                  <img alt="image" class="img-fluid w-100" src="assets/image/banner2.png">
              </div>
            </div>
          </div>
        </ng-template>  
        <ng-template carouselSlide>
          <div class="container pt-5">
            <div class="row align-items-center pt-5 pb-4">
              <div class="col-12 col-lg-6 mt-md-4 ml-md-auto text-left text-white left-reveal">
                  <h4>Business grow strategy is our mission</h4>
                  <h1 class="mt-4 h2">Take Your Business To The Next Level With Our Agency</h1>
                  <p class="mt-3 text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae soluta, dignissimos aut, assumenda dolore totam natus
                  qui cum vel omnis voluptates.</p>
                  <p class="mt-5" >
                      <a class="btn btn-primary rounded-pill px-sm-5 px-3 py-3 mt-4" href="#"> Contac Us</a>
                      <a class="btn btn-primary rounded-pill px-sm-5 px-3 py-3 ms-2 mt-4" href="#">Learn More</a> 
                  </p>
              </div>
              <div class="col-12 col-lg-6 mt-4 text-md-right right-reveal">
                  <img alt="image" class="img-fluid w-100" src="assets/image/banner2.png">
              </div>
            </div>
          </div>
        </ng-template>  
      <ng-template carouselSlide>
          <div class="container pt-5">
            <div class="row align-items-center pt-5 pb-4">
              <div class="col-12 col-lg-6 mt-md-4 ml-md-auto text-left text-white left-reveal">
                  <h4>Business grow strategy is our mission</h4>
                  <h1 class="mt-4 h2">Take Your Business To The Next Level With Our Agency</h1>
                  <p class="mt-3 text-white">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vitae soluta, dignissimos aut, assumenda dolore totam natus
                  qui cum vel omnis voluptates.</p>
                  <p class="mt-5" >
                      <a class="btn btn-primary rounded-pill px-sm-5 px-3 py-3 mt-4" href="#"> Contac Us</a>
                      <a class="btn btn-primary rounded-pill px-sm-5 px-3 py-3 ms-2 mt-4" href="#">Learn More</a> 
                  </p>
              </div>
              <div class="col-12 col-lg-6 mt-4 text-md-right right-reveal">
                  <img alt="image" class="img-fluid w-100" src="assets/image/banner2.png">
              </div>
            </div>
          </div>
        </ng-template>  
      </owl-carousel-o>
    </section>
  `,
  styles: [`
  
  `]
})
export class ClientLogoComponent implements OnInit {

// ngx-owl-carousel-o
  customOptions: OwlOptions = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: true,
    dots: true,
    navSpeed: 700,
    //navText: [ '<i class="material-icons">chevron_left</i>', '<i class="material-icons">chevron_right</i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 1
      },
      740: {
        items: 1
      },
      940: {
        items: 1,
      }
    },
    //nav: true
  }

  constructor() { }

  ngOnInit(): void {
  }

}
